import java.util.Random;
import java.util.ArrayList;
/**
 * Write a description of class Game here.
 * 
 * @author Joanna Zhang
 * @version 26/03/2016
 */
public class Game
{
    private int score;
    private int difficulty;
    //original sequence 
    private ArrayList<Integer> sequence = new ArrayList<>();
    //player input sequence
    private ArrayList<Integer> psequence = new ArrayList<>();
    private Random random;

    /**
     * Constructor for objects of class Game
     */
    public Game()
    {
        newGame();
    }

    /**
     * clear the current sequence and player sequence
     * Generates random numbers from 1-4 and puts them in sequence
     * up to the difficulty amount
     */
    public void sequence()
    {
        sequence.clear();
        psequence.clear();
        random = new Random();
        for(int i=0; i<difficulty; i++){
            sequence.add(random.nextInt(4)+1);
        }
    }
    
    /**
     * Checks to see if the player has won
     * 
     * @return 0 if lost, 1 if won, and 2 if no boundaries have been met
     */
    public int won()
    {
        if (score < 0)
        {
            return 0;
        }
        else if (score == 10)
        {
            return 1;
        }
        else {
            return 2;
        }
    }
    
    /**
     * Returns the original sequence
     * 
     * @return the ArrayList sequence
     */
    public ArrayList<Integer> returnOriginalSequence()
    {
        return sequence;
    }
    
    /**
     * Add an integer to the psequence arrayList
     * 
     * @param an int to add to the psequence arrayList
     */
    public void playerSequence(int x)
    {
        psequence.add(x);
    }
    
    /**
     * Sets the variables back to default
     */
    public void newGame()
    {
        difficulty = 3;
        score = 0;
    }
    
    /**
     * Checks to see the player has finished entering the sequence
     * and calls another method to see if they have scored
     * 
     * @return true if finished, false if not finished
     */
    public boolean checkFinish()
    {
        if(psequence.size() == sequence.size()){
            score();
            return true;            
        } 
        else {
            return false;
        }
    }
    
    /**
     * Checks to see the player has entered the sequence correctly
     * 
     * @return true if correct, and false if incorrect
     */
    private boolean compareList()
    {
        return sequence.toString().contentEquals(psequence.toString())?true:false;
    }
    
    /**
     * If the player has gotten the sequence right, add one to the score, and call the other methods 
     * to make a new sequence and to check if the difficulty needs to be upped.
     * Else, take one away from the score and check if the difficulty needs to be lowered.
     */
    private void score()
    {
        if(compareList())
        {
            score++;
            sequence();
            difficulty();
        }
        else{
            score--;           
            difficulty();
        }        
    }
    
    /**
     * Returns the current score
     * 
     * @return integer score
     */
    public int returnScore()
    {
        return score;
    }
        
    /**
     * if score is a certain number, change the difficulty to reflect it.
     * If it is lower than 3, set the difficulty to 3
     * if it is 3, set difficulty to 4
     * if score is 6, set difficulty to 5
     * if score is 9, set difficulty to 6
     */
    private void difficulty()
    {
        if (score < 3)
        {
            difficulty = 3;
        }
        
        if(score == 3)
        {
            difficulty = 4;
        }
        
        if(score == 6)
        {
            difficulty = 5;
        }
        
        if(score == 9)
        {
            difficulty = 6;
        }
    }
}
