import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.HashMap;

/**
 * GUI is the main class for this game. 
 * It builds and displays the application GUI and initialises all other components.
 * 
 * @author Joanna Zhang
 * @version 26/03/2016
 */
public class GUI extends JFrame
{
    private JFrame frame;
    private JLabel score = new JLabel("Score: 0" );
    private static final String VERSION = "Version 1.0";
    private Game game;
    private HashMap<Integer, JButton> buttonList = new HashMap<>();
    private JButton one;
    private JButton two;
    private JButton three;
    private JButton four;
    private boolean var;

    /**
     * Constructor for objects of class GUI
     * also creates a Game object that handles the game logic
     * creates another thread to handle scoring as to not halt the main thread
     */
    public static void main(String[] args){
        GUI GUI = new GUI();

    }
    
    public GUI()
    {
        game = new Game();
        var = true;
        game.sequence();
        start();
        new Thread (new Runnable(){
                public void run() {
                    while(var){
                        score.setText("Score: " + game.returnScore());
                        if(game.won() == 0)
                        {
                            //if score below zero, tell user they lost
                            exit();
                            game.newGame();
                        }
                        if(game.won() == 1)
                        {
                            //if score is 10, tell user they won
                            winner();
                            game.newGame();
                        }

                        try {
                            Thread.sleep(300);                 //1000 milliseconds is one second.                
                        } catch(InterruptedException ex) {
                            Thread.currentThread().interrupt();
                        }
                    }
                }
            }).start();
    }

    /**
     * Creates a pop up dialog box to let the user know that they lost
     * Removes all the frames and goes back to the default interface
     */
    private void exit()
    {
        JOptionPane.showMessageDialog(frame, 
            "You Lost\n",
            "Message", 
            JOptionPane.INFORMATION_MESSAGE);
        frame.removeAll(); 
        frame.dispatchEvent(new WindowEvent(frame, WindowEvent.WINDOW_CLOSING));
        start();
    }

    /**
     * Creates a pop up dialog box to let the user know that they won
     * Removes all the frames and goes back to the default interface
     */
    private void winner()
    {
        JOptionPane.showMessageDialog(frame, 
            "You Won!\n",
            "Message", 
            JOptionPane.INFORMATION_MESSAGE);
        frame.removeAll(); 
        frame.dispatchEvent(new WindowEvent(frame, WindowEvent.WINDOW_CLOSING));
        start(); 
    }

    /**
     * Creates a dialog box about the game
     */
    private void about()
    {
        JOptionPane.showMessageDialog(frame, 
            "Memory Game\n" + VERSION,
            "About Memory Game", 
            JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Creates a dialog box to give the user help about the game
     */
    private void help()
    {
        JOptionPane.showMessageDialog(frame, 
            "Repeat the sequence shown to you \n Click play to advance", "Help",
            JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Create the main frame's menu bar.
     * @param frame   The frame that the menu bar should be added to.
     */
    private void makeMenu(JFrame frame)
    {
        JMenuBar menubar = new JMenuBar();
        frame.setJMenuBar(menubar);
        
        // create the File menu
        JMenu fileMenu = new JMenu("File");
        menubar.add(fileMenu);

        JMenuItem restart = new JMenuItem("Restart");
        restart.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) { start(); }
            });
        fileMenu.add(restart);

        JMenuItem quit = new JMenuItem("Quit");
        quit.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) { quit(); }
            });
        fileMenu.add(quit);

        // create the File menu
        JMenu helpMenu = new JMenu("Help");
        menubar.add(helpMenu);

        JMenuItem about = new JMenuItem("About");
        about.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) { about(); }
            });
        helpMenu.add(about);

        JMenuItem help = new JMenuItem("Help");
        help.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) { help(); }
            });
        helpMenu.add(help);
    }

    /**
     * Create the Swing frame and its content for the menu screen.
     */
    private void start()
    {
        frame = new JFrame("Start Up");
        //Creates the panel for the 2 JButtons
        JPanel p = new JPanel(new GridLayout(1,2));
        Container contentPane = frame.getContentPane();
        contentPane.setLayout(new BorderLayout());
        //Adds the JPanel to the content Pane

        makeMenu(frame);

        contentPane.add(p, BorderLayout.CENTER);
        ActionListener game = new ActionListener() {
                public void actionPerformed(ActionEvent e) { 
                    reset(); }
            };  
        //button 1               
        JButton start = new JButton("START");
        start.addActionListener(game);
        p.add(start);

        ActionListener buttonListener = new ActionListener() {
                public void actionPerformed(ActionEvent e) { 
                    frame.removeAll(); 
                    frame.dispatchEvent(new WindowEvent(frame, WindowEvent.WINDOW_CLOSING)); }
            };          

        //button 2
        JButton quit = new JButton("QUIT");
        quit.addActionListener(buttonListener);
        p.add(quit);

        frame.pack();
        frame.setSize(800,200);
        frame.setVisible(true);
    }

    /**
     * Starts a clean game
     */
    private void reset()
    {
        frame.removeAll(); 
        frame.dispatchEvent(new WindowEvent(frame, WindowEvent.WINDOW_CLOSING));
        makeFrame(); 
    }

    /**
     * Removes all frames and closes down the game
     */
    private void quit()
    {
        frame.removeAll(); 
        frame.dispatchEvent(new WindowEvent(frame, WindowEvent.WINDOW_CLOSING)); 
    }

    /**
     * Creates a swing frame and its content for the game
     */
    private void makeFrame()
    {
        //creates the frame for the grid
        frame = new JFrame("Memory Game"); 

        //Creates the panel used for 4 JButtons that will flash
        JPanel p = new JPanel(new GridLayout(1,4));
        //Creates the panel used for 2 JButtons for options
        JPanel pane = new JPanel(new GridLayout(1,2));

        Container contentPane = frame.getContentPane();        
        //Creates a container
        contentPane.setLayout(new BorderLayout());

        //adds the score JLabel to the content pane
        contentPane.add(score, BorderLayout.NORTH);

        //Adds the JPanel into the content pane
        contentPane.add(p, BorderLayout.CENTER);
        
        makeMenu(frame);

        //button 1               
        one = new JButton();
        one.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) { 
                    //adds number referencing this button to an arrayList
                    game.playerSequence(1); 
                    //disables buttons if user has finished entering the sequence
                    buttonDisable();
                }
            });
        p.add(one);

        //button 2
        two = new JButton();
        two.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) { 
                    //adds number referencing this button to an arrayList
                    game.playerSequence(2);
                    //disables buttons if user has finished entering the sequence
                    buttonDisable();                   
                }
            });
        p.add(two);

        //button 3
        three = new JButton();
        three.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) { 
                    //adds number referencing this button to an arrayList
                    game.playerSequence(3); 
                    //disables buttons if user has finished entering the sequence
                    buttonDisable();
                }
            });
        p.add(three);

        //button 4
        four = new JButton();
        four.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) { 
                    //adds number referencing this button to an arrayList
                    game.playerSequence(4); 
                    //disables buttons if user has finished entering the sequence
                    buttonDisable();                   
                }
            });
        p.add(four);

        //adds buttons with a refence to a HashMap
        buttonList();
        
        //disable all the buttons in the buttonList
        for (JButton button : buttonList.values()) {
            button.setEnabled(false);
        }

        //add the JPanel pane to the contentPane
        contentPane.add(pane, BorderLayout.SOUTH);
        
        //JButton called play
        JButton play = new JButton("Play");

        play.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) { 
                    //initialse the random sequence in the game class
                    game.sequence();
                    //make the buttons flash
                    blink();
                }
            });
        pane.add(play);

        JButton quit = new JButton("Quit");
        quit.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) { quit(); }
            });
        pane.add(quit);

        frame.pack();
        frame.setSize(800,200);
        frame.setVisible(true);
    }

    /**
     * disables the buttons if the user has entered the correct amount of inputs
     */
    private void buttonDisable()
    {
        if(game.checkFinish()){
            for (JButton button : buttonList.values()) {
                button.setEnabled(false);
            }
        }
        else{
            for (JButton button : buttonList.values()) {
                button.setEnabled(true);
            }
        }  
    }

    /**
     * Adds the buttons into a hashMap with a number reference
     */
    private void buttonList()
    {
        buttonList.put(1, one); 
        buttonList.put(2, two); 
        buttonList.put(3, three); 
        buttonList.put(4, four); 
    }

    
    /**
     * Make the buttons change colour
     * creates another thread to handle flashing as to not halt the main thread
     */
    private void blink()
    {
        //disable buttons whilst flashing
        for (JButton button : buttonList.values()) {
            button.setEnabled(false);
        }
        new Thread (new Runnable(){
                public void run() {
                    // iterate through the original arrayList
                    for(int Integer : game.returnOriginalSequence())
                    {
                        //retrieve the JButton in accordance with the number in the HashMap
                        JButton currentButton = buttonList.get(Integer);
                        //assign the colour of the current button to a variable called back
                        Color back = currentButton.getBackground();
                        currentButton.setOpaque(true);
                        //set button to the colour red
                        currentButton.setBackground(Color.RED);
                        //refresh
                        repaint();
                        // sleep for 1/2 sec
                        try {
                            Thread.sleep(500);                               
                        } catch(InterruptedException ex) {
                            Thread.currentThread().interrupt();
                        }
                        //set colour to original colour
                        currentButton.setBackground(back);
                        //update
                        repaint();
                        //sleep for 0.3 ms to give appearance of blinking if same button comes on twice
                        try {
                            Thread.sleep(300);        
                        } catch(InterruptedException ex) {
                            Thread.currentThread().interrupt();
                        }                        
                    }
                    //enable buttons
                    for(JButton button : buttonList.values()){
                        button.setEnabled(true);
                    }
                }
            }).start();

    }
}
